<footer class="footer3">
        <div class="row" style="width: 95%">
            <div class="column3">
                <a href="index.html">Home</a>
            </div>
            <div class="column3">
                <a href="#">About</a>
            </div>
            <div class="column3">
                <a href="#">Customer Support</a>
            </div>
            <div class="column3">
                <a href="#">Transcation History</a>
            </div>
            <div class="column3">
                <a href="#">Transfer Money</a>
            </div>
            <div class="column3">
                <a href="#">Terms and Conditions</a>
            </div>
    </footer>