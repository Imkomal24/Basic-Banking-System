<header class="header">
        <nav class="navbar">
            <div class="logo">
                <img src="images/bank-icon.png" alt="logo">
            </div>
            <div class="menu">
                <div class="menuitems">
                    <a href="index.php">Home</a>
                </div>
                <div class="menuitems">
                    <a href="viewcustomers.php">View Customers</a>
                </div>
                <div class="menuitems">
                    <a href="transferhistory.php">Transaction History</a>
                </div>
                <div class="menuitems">
                    <a href="#">About</a>
                </div>
                <div class="menuitems">
                    <a href="#">Contact Us</a>
                </div>
            </div>
            <div class="navlink">
                <div class="navitems">
                    <a href="#" target="blank"><img src="images/instagram-logo.png" alt="instagram"></a>
                </div>
                <div class="navitems">
                    <a href="#" target="blank"><img src="images/twitter-logo.png" alt="twitter"></a>
                </div>
            </div>
        </nav>
        <hr>
    </header>